import sqlite3

connection = sqlite3.connect('database.db')


with open('schema.sql') as f:
    connection.executescript(f.read())

cur = connection.cursor()

cur.execute("INSERT INTO users (username, password, name, location) VALUES (?, ?, ?, ?)",
            ('ShifraGewanter', '**********', 'Shifra Gewanter', 'Queens, NY')
            )

cur.execute("INSERT INTO users (username, password, name, location) VALUES (?, ?, ?, ?)",
            ('ShifraGewanter', '**********', 'Shifra Gewanter', 'Queens, NY')
            )

connection.commit()
connection.close()