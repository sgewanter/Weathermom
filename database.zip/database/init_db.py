import sqlite3

connection = sqlite3.connect('database.db')


with open('schema.sql') as f:
    connection.executescript(f.read())

cur = connection.cursor()

cur.execute("INSERT INTO users (username, password, first_name, last_name, city, zip_code, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ('ShifraGewanter', '**********', 'Shifra', 'Gewanter', 'Queens', '11367', '111-222-3333')
            )

cur.execute("INSERT INTO users (username, password, first_name, last_name, city, zip_code, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)",
            ('ShifraGewanter', '**********', 'Shifra', 'Gewanter', 'Queens', '11367', '111-222-3333')
            )
connection.commit()
connection.close()